self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "472ec3c51a05034b1de2212b8ac06051",
    "url": "/index.html"
  },
  {
    "revision": "c5f96da18d9ce6534554",
    "url": "/static/css/main.a958ea84.chunk.css"
  },
  {
    "revision": "652a599d1a99efccd345",
    "url": "/static/js/2.a430f49c.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.a430f49c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c5f96da18d9ce6534554",
    "url": "/static/js/main.7c7ac093.chunk.js"
  },
  {
    "revision": "415e9bcf6c081ea50565",
    "url": "/static/js/runtime-main.f8c5b4be.js"
  },
  {
    "revision": "05e2a25130d9f3da91e8724804cf39c5",
    "url": "/static/media/daisy.05e2a251.jpg"
  }
]);